const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());

// Facebook verification endpoint
app.get('/webhook', (req, res) => {
    const VERIFY_TOKEN = process.env.VERIFY_TOKEN;
    const mode = req.query['hub.mode'];
    const token = req.query['hub.verify_token'];
    const challenge = req.query['hub.challenge'];

    if (mode === 'subscribe' && token === VERIFY_TOKEN) {
        console.log('WEBHOOK_VERIFIED');
        res.status(200).send(challenge);
    } else {
        res.sendStatus(403);
    }
});

// Facebook message receiver endpoint
app.post('/webhook', async (req, res) => {
    const body = req.body;
    if (body.object === 'page') {
        body.entry.forEach(async function(entry) {
            const webhook_event = entry.messaging[0];
            const sender_psid = webhook_event.sender.id;

            if (webhook_event.message && webhook_event.message.text) {
                const userMessage = webhook_event.message.text;
                const response = await sendToVoiceflow(sender_psid, userMessage);
                await sendMessage(sender_psid, response);
            }
        });
        res.status(200).send('EVENT_RECEIVED');
    } else {
        res.sendStatus(404);
    }
});

// Send message to Voiceflow and get response
async function sendToVoiceflow(userId, message) {
    const response = await axios.post(
        `https://general-runtime.voiceflow.com/state/${process.env.VOICEFLOW_VERSION_ID}/user/${userId}/interact`,
        { request: { type: 'text', payload: message } },
        {
            headers: {
                Authorization: process.env.VOICEFLOW_API_KEY,
                'Content-Type': 'application/json'
            }
        }
    );
    return response.data?.[0]?.payload?.message || 'Nu am înțeles.';
}

// Send response back to Messenger user
async function sendMessage(sender_psid, messageText) {
    const requestBody = {
        recipient: { id: sender_psid },
        message: { text: messageText }
    };

    await axios.post(
        `https://graph.facebook.com/v13.0/me/messages?access_token=${process.env.PAGE_ACCESS_TOKEN}`,
        requestBody
    );
}

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});